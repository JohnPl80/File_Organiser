# A program to find duplicate files, delete them or organize the files by type
# Author: John Plytas
# Anyone can use it and learn from it
# Not for commercial use

import os
import shutil
import hashlib
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from collections import defaultdict
import threading

# Function to calculate the MD5 hash of a file to identify duplicates
def calculate_md5(file_path):
    # Initialize hash object
    hash_md5 = hashlib.md5()
    try:
        # Open file in binary read mode
        with open(file_path, "rb") as f:
            # Read the file in chunks to avoid memory overload
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()
    except:
        return None

# Function to find duplicate files in a directory
def find_duplicates(directory, progress_var):
    # Dictionary to hold file hashes and their corresponding paths
    files_hash_map = defaultdict(list)
    total_files = sum([len(files) for r, d, files in os.walk(directory)])
    processed_files = 0
    
    # Traverse the directory and subdirectories
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_hash = calculate_md5(file_path)
            if file_hash:
                files_hash_map[file_hash].append(file_path)
            processed_files += 1
            progress_var.set((processed_files / total_files) * 100)
    
    # Filter out entries with only one file (no duplicates)
    duplicates = {hash_val: paths for hash_val, paths in files_hash_map.items() if len(paths) > 1}
    return duplicates

# Function to display duplicates in a GUI window
def show_duplicates(duplicates):
    if not duplicates:
        messagebox.showinfo("Duplicates", "No duplicates found!")
        return
    
    # Create a new window to display duplicates
    dup_window = tk.Toplevel()
    dup_window.title("Duplicate Files")
    
    # Frame to contain Treeview and scrollbar
    frame = tk.Frame(dup_window)
    frame.pack(fill=tk.BOTH, expand=True)

    # Treeview to show the list of duplicate files
    tree = ttk.Treeview(frame, columns=("File", "Path"), show="headings", selectmode="extended")
    tree.heading("File", text="File")
    tree.heading("Path", text="Path")
    tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Vertical scrollbar for Treeview
    scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    tree.configure(yscroll=scrollbar.set)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # Populate the Treeview with duplicate files
    for paths in duplicates.values():
        for path in paths:
            tree.insert("", "end", values=(os.path.basename(path), path))

    # Button to open selected file location
    def open_file_location():
        selected_items = tree.selection()
        if selected_items:
            file_path = tree.item(selected_items[0], 'values')[1]
            os.startfile(os.path.dirname(file_path))

    # Button to delete selected files
    def delete_files():
        selected_items = tree.selection()
        if selected_items:
            for item in selected_items:
                file_path = tree.item(item, 'values')[1]
                os.remove(file_path)
                tree.delete(item)
            messagebox.showinfo("Delete", "Selected files have been deleted.")

    # Button to select one file from each duplicate set
    def select_one_from_each_duplicate():
        # Clear any current selection
        tree.selection_remove(tree.selection())

        # Loop through duplicates and select the first file of each group
        for paths in duplicates.values():
            if len(paths) > 1:  # Ensure there are duplicates
                # Find the item ID for the first duplicate in the Treeview
                for item in tree.get_children():
                    file_path = tree.item(item, 'values')[1]
                    if file_path in paths:
                        tree.selection_add(item)
                        break  # Select only one from each duplicate group

    # Add buttons to the window
    open_button = tk.Button(dup_window, text="Open Folder", command=open_file_location)
    open_button.pack(side=tk.LEFT, padx=10, pady=10)

    delete_button = tk.Button(dup_window, text="Delete Selected Files", command=delete_files)
    delete_button.pack(side=tk.RIGHT, padx=10, pady=10)

    select_duplicates_button = tk.Button(dup_window, text="Select One from Each Duplicate Set", command=select_one_from_each_duplicate)
    select_duplicates_button.pack(side=tk.BOTTOM, padx=10, pady=10)

# Function to organize files by type
def organize_by_type(directory, progress_var):
    total_files = sum([len(files) for r, d, files in os.walk(directory)])
    processed_files = 0

    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_extension = os.path.splitext(file)[1][1:].lower()
            if file_extension:  # Ignore files with no extension
                target_folder = os.path.join(directory, file_extension.upper())
                os.makedirs(target_folder, exist_ok=True)
                shutil.move(file_path, os.path.join(target_folder, file))
            processed_files += 1
            progress_var.set((processed_files / total_files) * 100)
    
    messagebox.showinfo("Organize by Type", "Files have been organized by type!")

# Function to browse directory
def browse_directory():
    selected_dir = filedialog.askdirectory()
    if selected_dir:
        directory_entry.delete(0, tk.END)
        directory_entry.insert(0, selected_dir)

# Function to handle the organization choice
def handle_organize():
    selected_dir = directory_entry.get()
    if not os.path.isdir(selected_dir):
        messagebox.showerror("Error", "Please select a valid directory.")
        return
    
    progress_var.set(0)
    if choice_var.get() == 1:
        threading.Thread(target=lambda: show_duplicates(find_duplicates(selected_dir, progress_var))).start()
    elif choice_var.get() == 2:
        threading.Thread(target=lambda: organize_by_type(selected_dir, progress_var)).start()

# Initialize main window
window = tk.Tk()
window.title("File Organizer")

# GUI elements for selecting directory
tk.Label(window, text="Select Directory:").pack(pady=5)
directory_entry = tk.Entry(window, width=50)
directory_entry.pack(padx=10)
browse_button = tk.Button(window, text="Browse", command=browse_directory)
browse_button.pack(pady=5)

# Radio buttons for choosing organization method
choice_var = tk.IntVar()
tk.Radiobutton(window, text="Find Duplicates", variable=choice_var, value=1).pack(anchor=tk.W)
tk.Radiobutton(window, text="Organize by Type", variable=choice_var, value=2).pack(anchor=tk.W)

# Progress bar
progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(window, variable=progress_var, maximum=100)
progress_bar.pack(fill=tk.X, padx=10, pady=10)

# Button to start the organization process
organize_button = tk.Button(window, text="Organize", command=handle_organize)
organize_button.pack(pady=10)

# Start the GUI loop
window.mainloop()
